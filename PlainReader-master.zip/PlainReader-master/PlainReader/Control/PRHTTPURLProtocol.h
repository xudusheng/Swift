//
//  PRURLProtocol.h
//  PlainReader
//
//  Created by guojiubo on 14-4-25.
//  Copyright (c) 2014年 guojiubo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PRHTTPURLProtocol : NSURLProtocol

@end
