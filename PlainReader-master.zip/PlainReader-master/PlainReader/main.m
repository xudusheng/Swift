//
//  main.m
//  PlainReader
//
//  Created by guojiubo on 14-3-20.
//  Copyright (c) 2014年 guojiubo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
/*
 <div class="item" id="J_allItem_478727">
 <div class="hd">
 <div class="title">
 <a target="_blank" href="/articles/478727.htm">加大伯克利分校系统遭黑客入侵 8万名学生职工信息泄露</a>
 <div class="tj">
 <span>KungfuDogg 发布于<em>2016-02-27 15:12:23</em> | </span>
 <span><em>779</em> 次阅读</span>
 </div>
 </div>
 <div class="picno"><div class="pic"><a target="_blank" href="/articles/478727.htm"><img width="100" height="100" src="http://static.cnbetacdn.com/thumb/mini/article/2016/0227/545585dd0d0c5ea.jpg_100x100.jpg" /></a></div></div><span class="newsinfo"><p><strong>据加州当地媒体报道，当局周五确认加州大学伯克利分校的电脑系统被一名黑客侵入，导致8万名学生和校友，教职工以及前任员工的社安号和银行账号泄露</strong>。被黑客入侵的系统为伯克利金融系统，用来管理校园内的采购和非薪酬支付财务工作，如奖学金和工作费用报销等。</p></span>
 </div>
 <div class="clear"></div>
 <div class="tools repeat">
 <div class="time"><a target = "_blank" href = "http://click.aliyun.com/m/1961/"><b>9.9元学生特惠阿里云服务器｜送域名</b></a></div>
 <ul class="gray">
 <li><b><a target="_blank" href="/articles/478727.htm">详细内容</a></b></li>
 <li>已有<em>5</em>个意见&nbsp;&nbsp;|</li>
 <li><em>0</em>次推荐&nbsp;&nbsp;|</li>
 <li><em>0</em>次打分&nbsp;&nbsp;|</li>
 <li>事件分:<em>0</em>分&nbsp;&nbsp;|</li>
 <li>质量分:<em>0</em>分</li>
 </ul>
 </div>
 </div>
 */