//
//  WebViewController.h
//  PlainReader
//
//  Created by guojiubo on 14-5-22.
//  Copyright (c) 2014年 guojiubo. All rights reserved.
//

#import "PRPullToRefreshViewController.h"

@interface PRBrowserViewController : PRPullToRefreshViewController

@property (nonatomic, strong) NSURLRequest *request;

@end
