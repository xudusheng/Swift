//
//  PRTableViewController.h
//  PlainReader
//
//  Created by guo on 11/28/14.
//  Copyright (c) 2014 guojiubo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PRTableViewController : UITableViewController

@end
